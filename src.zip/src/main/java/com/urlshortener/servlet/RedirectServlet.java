package com.urlshortener.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/r/*")
public class RedirectServlet extends HttpServlet {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/urlshortenerdb";
    private static final String JDBC_USER = "youruser_name";
    private static final String JDBC_PASS = "yourpassword";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String shortCode = request.getPathInfo().substring(1); // e.g. /aB12cD → aB12cD
        String longUrl = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            String query = "SELECT long_url FROM urls WHERE short_code = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, shortCode);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                longUrl = rs.getString("long_url");
            }

            conn.close();

            if (longUrl != null) {
                response.sendRedirect(longUrl); // redirect to the original URL
            } else {
                response.setContentType("text/html");
                response.getWriter().println("<h3>❌ Invalid or expired short URL!</h3>");
            }

        } catch (Exception e) {
            e.printStackTrace(response.getWriter());
        }
    }
}
