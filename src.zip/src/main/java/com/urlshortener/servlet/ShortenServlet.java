package com.urlshortener.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Random;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/shorten")
public class ShortenServlet extends HttpServlet {

    // JDBC Configuration
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/urlshortenerdb";
    private static final String JDBC_USER = "VARUN2027";       // your MySQL username
    private static final String JDBC_PASS = "VaRuN2027@";      // your MySQL password

    // Random short code generator
    private String generateShortCode() {
        String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder shortCode = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 6; i++) {
            shortCode.append(chars.charAt(random.nextInt(chars.length())));
        }
        return shortCode.toString();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // ✅ Corrected parameter name (case-sensitive)
        String longUrl = request.getParameter("longUrl");
        String shortCode = generateShortCode();

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Step 1: Load MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Step 2: Connect to database
            Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            // Step 3: Insert URL mapping
            String insertQuery = "INSERT INTO urls (long_url, short_code) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(insertQuery);
            ps.setString(1, longUrl);
            ps.setString(2, shortCode);
            ps.executeUpdate();

            conn.close();

            // Step 4: Display Result
            out.println("<h2 style='text-align:center; margin-top:100px;'>");
            out.println("✅ Short URL created successfully!<br>");
            out.println("Original URL: " + longUrl + "<br>");
            out.println("Short URL: <a href='" + request.getContextPath() + "/r/" + shortCode + "'>"
                    + request.getRequestURL().toString().replace("shorten", "r/" + shortCode) + "</a>");
            out.println("</h2>");

        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }
}
